package com.example.j

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.speech.*
import android.speech.tts.*
import java.text.SimpleDateFormat
import java.util.*

enum class Mood(val pitch: Float, val rate: Float) {
    HAPPY(1.12f, 1.08f), CALM(1.0f, 1.0f), SORRY(0.9f, 0.92f), EXCITED(1.2f, 1.15f)
}

class JService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var rec: SpeechRecognizer? = null
    private val ui = Handler(Looper.getMainLooper())
    private var awakeUntil = 0L
    private var speaking = false
    private var lastReply = ""
    private var wl: PowerManager.WakeLock? = null

    private val wakeReplies = listOf(
        "Yes boss, I'm here!", "At your service.", "Online and listening.",
        "Right here. What do you need?", "Always on, boss. Go ahead.",
        "J reporting in. How can I help?", "I'm all ears.", "Standing by, boss.",
        "Ready when you are.", "Yes? I'm listening.", "Hey boss! What's the plan?", "Locked in. Tell me.")
    private val doneReplies = listOf("On it!", "Done, boss.", "Right away!", "Consider it done.", "Sure thing!")
    private val wake = Regex("^(?:(?:hey|hi|ok|okay|hello)\\s+)?(?:j|jay|jey|jai|jae)\\b[,.]?\\s*(.*)$")
    private val stopWords = setOf("ko", "karo", "kar", "do", "de", "please", "pls", "to", "me", "mujhe", "zara",
        "jara", "the", "app", "a", "for", "on", "and", "kholo", "khol", "open", "launch", "start", "call",
        "phone", "dial", "dialer", "chalu", "can", "you")

    private val sttIntent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) listen() else handle(t)
        }
        override fun onError(e: Int) { ui.postDelayed({ listen() }, if (e == 8) 500L else 120L) }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("j", "J", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "j").setContentTitle("J is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        wl = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "J:listen").apply { acquire() }
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onInit(s: Int) {
        // pick the best installed English voice (Indian English preferred)
        val v = tts.voices?.filter { it.locale.language == "en" && !it.features.contains("notInstalled") }
            ?.maxByOrNull { it.quality + (if (it.locale.country == "IN") 100 else 0) }
        if (v != null) tts.voice = v else tts.language = Locale("en", "IN")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { speaking = false; ui.post { listen() } }
            override fun onError(id: String?) { speaking = false; ui.post { listen() } }
        })
        listen()
    }

    private fun say(t: String, m: Mood = Mood.HAPPY) {
        speaking = true
        rec?.cancel()
        tts.setPitch(m.pitch); tts.setSpeechRate(m.rate)
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    private fun pick(l: List<String>): String {
        val r = l.filter { it != lastReply }.random(); lastReply = r; return r
    }

    private fun listen() {
        if (speaking) return
        if (rec == null) rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        rec!!.cancel()
        rec!!.startListening(sttIntent)
    }

    private fun handle(raw: String) {
        val t = raw.lowercase().trim()
        val m = wake.find(t)
        val awake = System.currentTimeMillis() < awakeUntil
        val cmd = when {
            m != null -> m.groupValues[1].trim()
            awake -> t
            else -> { listen(); return }
        }
        awakeUntil = System.currentTimeMillis() + 10_000   // stay awake 10s: no need to repeat "Hey J"
        if (cmd.isEmpty()) say(pick(wakeReplies)) else run(cmd)
    }

    private fun go(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9 ]"), "").trim()
    private fun clean(c: String) = norm(c).split(" ").filter { it.isNotBlank() && it !in stopWords }.joinToString(" ")

    private fun sim(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        if (a in b || b in a) return 0.9
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return 1.0 - d[a.length][b.length].toDouble() / maxOf(a.length, b.length)
    }

    private fun run(c: String) {
        val w = c.split(" ").filter { it.isNotBlank() }
        fun has(vararg k: String) = w.any { it in k }
        try {
            when {
                has("stop", "cancel", "sleep", "bye") -> { awakeUntil = 0; say("Okay boss, call me when you need me.", Mood.CALM) }
                has("thanks", "thank", "shukriya") -> say("Anytime, boss!")
                has("search", "google", "dhundo", "khojo") -> search(c)
                has("call", "phone", "dial") -> call(clean(c))
                has("torch", "flashlight") -> {
                    val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                    val on = !has("off", "band")
                    cm.setTorchMode(cm.cameraIdList[0], on)
                    say(if (on) "Torch on." else "Torch off.")
                }
                has("volume") -> {
                    val am = getSystemService(AUDIO_SERVICE) as AudioManager
                    val up = has("up", "increase", "badha", "zyada")
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    say(if (up) "Volume up." else "Volume down.")
                }
                has("time", "samay") -> say("It's " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()), Mood.CALM)
                has("battery") -> {
                    val b = (getSystemService(BATTERY_SERVICE) as BatteryManager)
                        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    say("Battery is at $b percent.", Mood.CALM)
                }
                else -> openApp(clean(c))
            }
        } catch (e: Exception) { say("Sorry boss, something went wrong.", Mood.SORRY) }
    }

    private fun search(c: String) {
        var q = Regex("(?:search for|search|google|dhundo|khojo)\\s+(.*)").find(c)?.groupValues?.get(1) ?: ""
        q = q.replace(Regex("\\s+(on|in) (chrome|google|youtube)$"), "").trim()
        if (q.isEmpty()) return say("What should I search for?", Mood.CALM)
        val yt = "youtube" in c
        val url = if (yt) "https://www.youtube.com/results?search_query=" else "https://www.google.com/search?q="
        say(pick(doneReplies))
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url + Uri.encode(q)))
        try { go(if (yt) i else i.setPackage("com.android.chrome")) }
        catch (e: Exception) { go(Intent(Intent.ACTION_VIEW, Uri.parse(url + Uri.encode(q)))) }
    }

    private fun openApp(name: String) {
        if (name.isEmpty()) return say("Which app, boss?", Mood.CALM)
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val best = pm.queryIntentActivities(main, 0)
            .map { it to sim(name, norm(it.loadLabel(pm).toString())) }.maxByOrNull { it.second }
        val i = if (best != null && best.second >= 0.6) pm.getLaunchIntentForPackage(best.first.activityInfo.packageName) else null
        if (i == null) say("I couldn't find $name.", Mood.SORRY)
        else { say(pick(doneReplies)); go(i) }
    }

    private fun call(name: String) {
        if (name.isEmpty()) return say("Who should I call?", Mood.CALM)
        val q = norm(name)
        var best: Pair<String, String>? = null
        var bs = 0.0
        contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val nn = norm(n)
                val s = maxOf(sim(q, nn), nn.split(" ").maxOf { sim(q, it) })
                if (s > bs) { bs = s; best = n to (c.getString(1) ?: "") }
            }
        }
        val hit = best
        if (hit == null || bs < 0.6) return say("I couldn't find $name in your contacts.", Mood.SORRY)
        say("Calling ${hit.first}.", Mood.CALM)
        ui.postDelayed({ go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(hit.second)))) }, 700)
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { rec?.destroy(); tts.shutdown(); wl?.release(); super.onDestroy() }
}
