package com.example.j

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS), 1)
        // Needed so J can open apps while running in background
        if (!Settings.canDrawOverlays(this))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }
    // Start the service only after the mic permission is granted
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        startForegroundService(Intent(this, JService::class.java))
        finish()
    }
}
