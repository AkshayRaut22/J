package com.example.j

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.*
import java.util.Locale

class JService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var rec: SpeechRecognizer? = null
    private val ui = Handler(Looper.getMainLooper())
    private var awake = false
    private var speaking = false

    private val wakeReplies = listOf(
        "Yes boss, I'm here.", "At your service.", "Online and listening.",
        "Right here. What do you need?", "Always on, boss. Go ahead.",
        "J reporting. How can I help?", "I'm all ears.", "Standing by.",
        "Ready when you are.", "Yes? I'm listening.")
    private val doneReplies = listOf("Done.", "On it.", "Consider it done.", "Right away, boss.")
    private val wakeRegex = Regex("\\b(hey |ok |okay )?(j|jay|jey)\\b")

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("j", "J", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "j").setContentTitle("J is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        tts.language = Locale("en", "IN")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true }
            override fun onDone(id: String?) { speaking = false; ui.post { listen() } }
            override fun onError(id: String?) { speaking = false; ui.post { listen() } }
        })
        listen()
    }

    private fun say(t: String) { speaking = true; tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j") }

    private fun listen() {
        if (speaking) return
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle) {
                    val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t != null) handle(t.lowercase()) else listen()
                }
                override fun onError(e: Int) { ui.postDelayed({ listen() }, 400) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true) // works offline if language pack is downloaded
            })
        }
    }

    private fun handle(text: String) {
        var cmd = text
        if (!awake) {
            val m = wakeRegex.find(text) ?: return listen()
            awake = true
            cmd = text.substring(m.range.last + 1).trim()
            if (cmd.isEmpty()) return say(wakeReplies.random())
        }
        awake = false
        run(cmd)
    }

    private fun go(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun run(c: String) {
        try {
            when {
                "search" in c -> {
                    val q = c.substringAfter("search for", c.substringAfter("search")).trim()
                    say(doneReplies.random())
                    go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                        .setPackage("com.android.chrome"))
                }
                c.startsWith("call ") || c.startsWith("phone ") -> call(c.substringAfter(" ").trim())
                c.startsWith("open ") || c.startsWith("launch ") -> openApp(c.substringAfter(" ").trim())
                else -> say("Sorry boss, I didn't get that.")
            }
        } catch (e: Exception) { say("Something went wrong.") }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getLaunchIntentForPackage(it.packageName) != null &&
            pm.getApplicationLabel(it).toString().lowercase().contains(name)
        }
        val i = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (i == null) say("I couldn't find $name.") else { say("Opening $name."); go(i) }
    }

    private fun call(name: String) {
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use {
            if (it.moveToFirst()) {
                say("Calling $name.")
                go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(it.getString(0)))))
            } else say("I couldn't find $name in your contacts.")
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { rec?.destroy(); tts.shutdown(); super.onDestroy() }
}
